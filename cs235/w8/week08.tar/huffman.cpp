/***********************************************************************
 * Module:
 *    Week 08, Huffman
 *    Brother Helfrich, CS 235
 * Author:
 *    <your name>
 * Summary:
 *    This program will implement the huffman() function
 ************************************************************************/

#include "huffman.h"       // for HUFFMAN() prototype
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

using std::string;

/*******************************************
 * HUFFMAN
 * Driver program to exercise the huffman generation code
 *******************************************/
void huffman(string filename)
{
    BinaryNode <double> *huffTree = NULL;
    double words;

    ifstream fin(filename.c_str());
    while (fin >> words)
    {
        if (huffTree == NULL)
            huffTree = new BinaryNode<double> (words);
        else if (huffTree->pLeft)
            huffTree->addLeft(words);
        else
            huffTree->addRight(words);
    }

    fin.close();

    cout << huffTree << endl;

   return;
}
